# Reward Hub — Free Demo Website

یہ ایک responsive demo reward website ہے۔

## چلانے کا طریقہ
1. `index.html`, `style.css`, `script.js` ایک ہی فولڈر میں رکھیں۔
2. `index.html` موبائل یا کمپیوٹر کے browser میں کھولیں۔
3. اسے مفت hosting پر publish کیا جا سکتا ہے۔

## اہم
یہ demo حقیقی رقم یا حقیقی ads نہیں دیتا۔ Google AdSense/کسی ad network کو استعمال کرنے سے پہلے اس کی policies، eligibility اور مقامی قوانین چیک کریں۔ Reward-for-ad systems بعض ad networks کی policies کے خلاف ہو سکتے ہیں۔
