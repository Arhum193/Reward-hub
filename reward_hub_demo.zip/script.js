let points=Number(localStorage.getItem('points')||0);const pointsEl=document.getElementById('points');pointsEl.textContent=points;
function toast(t){const e=document.getElementById('toast');e.textContent=t;e.style.display='block';setTimeout(()=>e.style.display='none',2500)}
function showMsg(t){toast(t)}
function watchAd(){toast('Demo: Ad شروع ہو گیا۔ حقیقی ad یہاں approved network سے آئے گا۔');setTimeout(()=>{points+=10;localStorage.setItem('points',points);pointsEl.textContent=points;toast('Demo Ad مکمل — 10 پوائنٹس شامل ہوئے!')},3000)}
function redeem(n){if(points<n){toast('اس reward کے لیے مزید پوائنٹس درکار ہیں۔');return}toast('Demo redeem request تیار ہے۔ حقیقی payment system ابھی شامل نہیں ہے۔')}
